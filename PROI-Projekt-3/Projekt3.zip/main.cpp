#include "Preprocesor.h"

int main()
{
	Preprocesor preproc;
    preproc.wczytaj();
    preproc.podmien();
    preproc.zapisz();
	return 0;
}
