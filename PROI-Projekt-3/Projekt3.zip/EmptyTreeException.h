#ifndef EMPTYTREEEXCEPTION
#define EMPTYTREEEXCEPTION

#include <iostream>
#include <exception>

using namespace std;

class EmptyTreeException: public exception
{

};

#endif // EMPTYTREEEXCEPTION
