#ifndef NOTFOUNDEXCEPTION
#define NOTFOUNDEXCEPTION

#include <iostream>
#include <exception>

using namespace std;

class NotFoundException: public exception
{

};

#endif // NOTFOUNDEXCEPTION
